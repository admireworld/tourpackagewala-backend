/**
 * AdmireDworld Travel — strict permanent storage helper
 * ------------------------------------------------------
 * Used by fixed.js, customize.js, settings.js and ai-provider.js so their
 * data survives Render restarts (same MongoDB Atlas cluster + same
 * "stores" collection that store.js already uses for bookings/leads/etc).
 *
 * Why not just use store.js?
 *   store.js quietly falls back to a local file when Mongo hiccups. For
 *   data that gets edited read-modify-write (seats, catalogs, settings)
 *   that is dangerous: a short Mongo blip could make the code read the
 *   *seed/default* data and then save it over your real data. This helper
 *   is STRICT instead — if Mongo is configured but unreachable it throws
 *   (the request fails with an error) rather than ever overwriting real
 *   data with defaults.
 *
 * Behaviour
 *   - MONGODB_URI set   -> data lives in MongoDB: { _id: name, data: {...} }
 *   - MONGODB_URI unset -> exactly the old behaviour (local JSON file).
 *   - First run after this update: if Mongo has nothing for that name yet,
 *     it picks up whatever is in the old local JSON file (nothing is lost),
 *     else the seed/default data.
 *
 * Main export: cachedDoc(name, file, makeDefault, [normalize])
 *   Keeps the document in memory so existing synchronous code
 *   (loadData()/saveData(), getSettings()) keeps working unchanged:
 *     doc.ensure()  -> Promise; resolves once loaded from Mongo/file
 *                      (rejects if Mongo is configured but unreachable)
 *     doc.get()     -> sync, returns a fresh deep copy (like re-reading a file)
 *     doc.set(data) -> sync, updates memory and saves to Mongo in the
 *                      background (writes are queued, latest state wins)
 *     doc.middleware-> express middleware: waits for ensure(), else 503
 */

const fs = require("fs");
const { getDb, isConfigured } = require("./db");

const clone = (x) => JSON.parse(JSON.stringify(x));

function readLocal(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

async function load(name, file, makeDefault) {
  if (isConfigured()) {
    const db = await getDb();
    if (!db) throw new Error("MongoDB is configured but not reachable right now.");
    const doc = await db.collection("stores").findOne({ _id: name });
    if (doc && doc.data) return doc.data;
    try {
      return readLocal(file); // one-time carry-over of the old local data
    } catch {
      return makeDefault();
    }
  }
  try {
    return readLocal(file);
  } catch {
    return makeDefault();
  }
}

async function save(name, file, data) {
  if (isConfigured()) {
    const db = await getDb();
    if (!db) throw new Error("MongoDB is configured but not reachable right now.");
    await db
      .collection("stores")
      .updateOne({ _id: name }, { $set: { data, updatedAt: new Date() } }, { upsert: true });
    return;
  }
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
  } catch (err) {
    console.error(`persist: could not write ${file} (continuing without persisting it):`, err.message);
  }
}

function cachedDoc(name, file, makeDefault, normalize) {
  let cache = null;
  let hydrated = false; // true only after a successful load from Mongo/file
  let loading = null;
  let writeChain = Promise.resolve();

  function ensure() {
    if (hydrated) return Promise.resolve();
    if (!loading) {
      loading = load(name, file, makeDefault)
        .then((d) => {
          cache = normalize ? normalize(d) : d;
          hydrated = true;
        })
        .finally(() => {
          loading = null;
        });
    }
    return loading;
  }

  function get() {
    if (!hydrated && !loading) ensure().catch((err) => console.error(`persist(${name}): load failed:`, err.message));
    return clone(cache !== null ? cache : makeDefault());
  }

  function set(data) {
    cache = clone(data);
    if (isConfigured() && !hydrated) {
      // Never push a not-fully-loaded copy over the real data in Mongo.
      console.error(`persist(${name}): change kept in memory only — MongoDB data was not loaded yet.`);
      return;
    }
    const snapshot = clone(cache);
    writeChain = writeChain
      .then(() => save(name, file, snapshot))
      .catch((err) => console.error(`persist(${name}): save failed (next save will retry with the latest data):`, err.message));
  }

  function middleware(req, res, next) {
    ensure().then(
      () => next(),
      (err) => {
        console.error(`persist(${name}):`, err.message);
        res.status(503).json({ error: "Database temporarily unavailable. Please try again in a moment." });
      }
    );
  }

  // Start loading right away at boot so the first request is usually instant.
  ensure().catch((err) => console.error(`persist(${name}): initial load failed:`, err.message));

  return { ensure, get, set, middleware };
}

module.exports = { cachedDoc, load, save };
