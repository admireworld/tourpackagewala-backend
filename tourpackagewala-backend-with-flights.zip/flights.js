/**
 * AdmireDworld Travel — Flights module (NEW, additive)
 * -----------------------------------------------------
 * Does not touch any existing route/file. Mount in server.js with:
 *   app.use("/api/customize/flights", require("./flights").router);
 *
 * What it does
 * ------------
 * On the "Customize Package" builder, a customer who has NOT ticked
 * "Land Only" can now search real flights and pick one. That flight's
 * price is folded into the SAME combined total that customize.js already
 * computes for hotel + sightseeing + transfers + visa (see
 * computeQuote() in customize.js) — exactly what was asked for: select
 * your flight, and its cost gets added into the one quotation total.
 *
 * Provider: SerpApi's Google Flights engine
 *   Docs: https://serpapi.com/google-flights-api
 *   Env var: SERPAPI_KEY  (server-side only — NEVER sent to the browser)
 *
 * Trust model (same rule the rest of customize.js follows — a price is
 * NEVER trusted back from the browser as a plain number):
 *   GET /search below returns flight options where each option carries a
 *   signed "flightToken" instead of a plain price. customize.js's
 *   /quote and /enquiry pass that token to verifyFlightToken() (exported
 *   below) and use ONLY the price sealed inside the verified token — a
 *   tampered/expired token is rejected outright. Signing (HMAC-SHA256)
 *   means no database/cache is needed and it survives Render free-tier
 *   restarts, unlike an in-memory cache would.
 *
 * This file is intentionally standalone: if SERPAPI_KEY is not set, the
 * /search route just replies 503 and every existing flow (hotel-only
 * customize quotes, "Land Only" bookings, everything else in the whole
 * project) keeps working exactly as before.
 */

const express = require("express");
const crypto = require("crypto");
const rateLimit = require("express-rate-limit");

const router = express.Router();

const SERPAPI_KEY = process.env.SERPAPI_KEY || "";
// Falls back to ADMIN_KEY so nothing new is *required* to deploy this,
// but for production it's best to set FLIGHT_TOKEN_SECRET explicitly
// (see README-DEPLOY.md).
const TOKEN_SECRET =
  process.env.FLIGHT_TOKEN_SECRET || process.env.ADMIN_KEY || "admiredworld-flight-token-dev-secret";
const TOKEN_TTL_MS = 30 * 60 * 1000; // 30 min — enough to pick a flight and finish the quote/enquiry

// Approximate primary/metro airport code for every destination already
// seeded in customize.js. Used only to query SerpApi — never shown to the
// customer. Add more here if new Customize Package destinations are added.
const DESTINATION_AIRPORTS = {
  Goa: "GOI",
  Kerala: "COK",
  Kashmir: "SXR",
  Manali: "KUU",
  Rajasthan: "JAI",
  Bali: "DPS",
  Dubai: "DXB",
  Thailand: "BKK",
};

// Major Indian departure cities, for a friendly dropdown on the frontend.
// A customer can also type any 3-letter IATA code directly (see resolveAirport).
const INDIA_DEPARTURE_CITIES = {
  Delhi: "DEL",
  Mumbai: "BOM",
  Bengaluru: "BLR",
  Kolkata: "CCU",
  Chennai: "MAA",
  Hyderabad: "HYD",
  Pune: "PNQ",
  Ahmedabad: "AMD",
  Jaipur: "JAI",
  Kochi: "COK",
  Goa: "GOI",
  Lucknow: "LKO",
};

function resolveAirport(input, cityMap) {
  if (!input) return null;
  const raw = String(input).trim();
  if (/^[A-Za-z]{3}$/.test(raw)) return raw.toUpperCase(); // already an IATA code
  const key = Object.keys(cityMap).find((k) => k.toLowerCase() === raw.toLowerCase());
  return key ? cityMap[key] : null;
}

/* ---------- Signed flight price token (stateless — no DB/cache) ---------- */
function signFlightToken(payload) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + TOKEN_TTL_MS })).toString("base64url");
  const sig = crypto.createHmac("sha256", TOKEN_SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
}

function verifyFlightToken(token) {
  if (!token || typeof token !== "string" || !token.includes(".")) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = crypto.createHmac("sha256", TOKEN_SECRET).update(body).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null; // tampered
  let payload;
  try {
    payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  } catch {
    return null;
  }
  if (!payload || typeof payload.price !== "number" || !payload.exp) return null;
  if (Date.now() > payload.exp) return null; // expired — ask the customer to search again
  return payload; // { airline, flightNumber, from, to, date, returnDate, price, exp }
}

const searchLimiter = rateLimit({ windowMs: 5 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });

/* ================================================================
   PUBLIC ROUTE
================================================================ */

// GET /api/customize/flights/search?destination=Goa&from=Delhi&date=2026-12-10&returnDate=2026-12-15&adults=2
// Live flight search for the Customize Package builder's "With Flight" step.
router.get("/search", searchLimiter, async (req, res) => {
  if (!SERPAPI_KEY) {
    return res
      .status(503)
      .json({ error: "Flight search isn't set up yet. Please contact us and we'll quote flights manually." });
  }

  const { destination, from, date, returnDate, adults } = req.query || {};
  const arrivalCode = resolveAirport(destination, DESTINATION_AIRPORTS) || DESTINATION_AIRPORTS[destination];
  const departureCode = resolveAirport(from, INDIA_DEPARTURE_CITIES);

  if (!arrivalCode) {
    return res.status(400).json({ error: `Flight search isn't available for "${destination}" yet.` });
  }
  if (!departureCode) {
    return res.status(400).json({ error: "Please choose a departure city, or enter a valid 3-letter airport code." });
  }
  if (!date) {
    return res.status(400).json({ error: "Please pick a departure date first." });
  }

  const travellerCount = Math.max(1, Math.min(9, Number(adults) || 1));
  const params = new URLSearchParams({
    engine: "google_flights",
    departure_id: departureCode,
    arrival_id: arrivalCode,
    outbound_date: String(date),
    type: returnDate ? "1" : "2", // 1 = round trip, 2 = one way
    currency: "INR",
    hl: "en",
    gl: "in",
    adults: String(travellerCount),
    api_key: SERPAPI_KEY,
  });
  if (returnDate) params.set("return_date", String(returnDate));

  try {
    const apiRes = await fetch(`https://serpapi.com/search.json?${params.toString()}`);
    const raw = await apiRes.json();
    if (!apiRes.ok || raw.error) {
      return res.status(502).json({ error: raw.error || "Flight search failed. Please try again." });
    }

    const groups = [...(raw.best_flights || []), ...(raw.other_flights || [])];
    if (!groups.length) {
      return res.json({ ok: true, options: [] });
    }

    const options = groups.slice(0, 12).map((g) => {
      const legs = Array.isArray(g.flights) ? g.flights : [];
      const first = legs[0] || {};
      const last = legs[legs.length - 1] || first;
      const price = Number(g.price) || 0; // SerpApi returns this per adult, in INR (currency=INR above)

      const flightData = {
        airline: first.airline || "Multiple airlines",
        airlineLogo: first.airline_logo || "",
        flightNumber: first.flight_number || "",
        from: (first.departure_airport && first.departure_airport.id) || departureCode,
        to: (last.arrival_airport && last.arrival_airport.id) || arrivalCode,
        departureTime: (first.departure_airport && first.departure_airport.time) || "",
        arrivalTime: (last.arrival_airport && last.arrival_airport.time) || "",
        durationMinutes: g.total_duration || null,
        stops: Math.max(0, legs.length - 1),
        date: String(date),
        returnDate: returnDate ? String(returnDate) : "",
        price,
      };

      return { ...flightData, flightToken: signFlightToken(flightData) };
    });

    res.json({ ok: true, travellers: travellerCount, options });
  } catch (err) {
    console.error("flights/search failed:", err.message);
    res.status(502).json({ error: "Flight search failed. Please try again." });
  }
});

module.exports = { router, verifyFlightToken };
